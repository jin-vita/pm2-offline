
setInterval(function() {
  console.log(process.env.JSONTEST);
}, 50);
