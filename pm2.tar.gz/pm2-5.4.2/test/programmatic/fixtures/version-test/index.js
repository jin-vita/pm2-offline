
setInterval(function() {
  console.log('HEY')
}, 1000)
