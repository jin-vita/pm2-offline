
console.log(process.env.TOTO);
