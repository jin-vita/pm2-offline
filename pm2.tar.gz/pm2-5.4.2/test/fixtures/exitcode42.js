setInterval(function() {
    console.log('BYE');
    process.exit(42);
  }, 500);
