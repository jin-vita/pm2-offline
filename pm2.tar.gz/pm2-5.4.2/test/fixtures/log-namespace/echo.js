console.log("start");
setInterval(function () {
  console.log("tick");
}, 50);
