module.exports = {

  apps : [


    {
      name      : 'Test es6 modules',
      script    : 'index.mjs',
      node_args : '--experimental-modules'
    }
  ],


};
