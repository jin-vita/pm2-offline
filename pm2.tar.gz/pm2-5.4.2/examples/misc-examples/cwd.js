

console.log(process.env.PWD);
console.log(process.cwd());
console.log(__dirname);

require('./echo.js');

console.log(process.cwd());

