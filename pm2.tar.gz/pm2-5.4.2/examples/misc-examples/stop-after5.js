
setTimeout(function() {
  process.exit(0);
}, 5000);
