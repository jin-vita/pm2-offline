setTimeout(() => {
  throw new Error('err')
}, 1500)
